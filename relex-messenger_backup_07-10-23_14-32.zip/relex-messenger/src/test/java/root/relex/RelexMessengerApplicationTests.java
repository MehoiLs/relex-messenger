package root.relex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelexMessengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
