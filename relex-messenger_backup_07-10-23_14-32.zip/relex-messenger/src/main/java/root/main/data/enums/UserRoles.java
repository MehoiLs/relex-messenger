package root.main.data.enums;

public enum UserRoles {
    USER,
    MODERATOR,
    ADMIN
}
