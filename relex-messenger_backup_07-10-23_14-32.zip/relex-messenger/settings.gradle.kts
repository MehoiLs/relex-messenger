rootProject.name = "relex-messenger"
