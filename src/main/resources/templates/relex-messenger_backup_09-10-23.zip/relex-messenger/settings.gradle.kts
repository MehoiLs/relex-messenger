rootProject.name = "relex-messenger"
