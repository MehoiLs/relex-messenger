package root.main.services.community;

import org.springframework.stereotype.Service;

@Service
public class UserMessageService {

    //TODO with WebSockets!

}
