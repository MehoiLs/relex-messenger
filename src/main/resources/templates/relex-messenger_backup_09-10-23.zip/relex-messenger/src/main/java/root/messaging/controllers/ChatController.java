package root.messaging.controllers;

import jakarta.annotation.security.PermitAll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import root.main.data.User;
import root.main.exceptions.TokenIsInvalidatedException;
import root.main.exceptions.TokenNotFoundException;
import root.main.services.UserService;
import root.messaging.data.ChatMessage;
import root.messaging.data.dto.MessengerFormDTO;
import root.security.general.components.JwtAuthenticationProvider;

@Controller
public class ChatController {

    @Autowired
    UserService userService;

    @Autowired
    JwtAuthenticationProvider authenticationProvider;

    @GetMapping("/messenger")
    public String messengerPage(Model model) {
        model.addAttribute("messengerForm", new MessengerFormDTO());
        return "messenger_validation";
    }

    @PostMapping("/messenger/validate")
    public String validateTokenAndRecipient(@ModelAttribute MessengerFormDTO messengerForm,
                                            Model model) {
        try {
            Authentication auth = authenticationProvider.validateToken(messengerForm.getToken());
            SecurityContextHolder.getContext().setAuthentication(auth);
            model.addAttribute("username", userService.getUserByAuth(auth));
            return "redirect:/messenger_chat";
        } catch (TokenIsInvalidatedException | TokenNotFoundException e) {
            return "error";
        }
    }

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
        return chatMessage;
    }

    @MessageMapping("/chat.sendPrivateMessage")
    @SendToUser("/queue/private")
    public ChatMessage sendPrivateMessage(@Payload ChatMessage chatMessage,
                                          @AuthenticationPrincipal User user) {
        String recipient = chatMessage.getReceiver();
        chatMessage.setSender(user.getUsername());
        return userService.getUserByUsername(recipient) == null
                ? new ChatMessage() : chatMessage;
    }

    @MessageMapping("/chat.addUser")
    @SendToUser("/topic/private")
    public ChatMessage addUser(@Payload ChatMessage chatMessage,
                               @AuthenticationPrincipal User user) {
        // Extract user information from JWT
        chatMessage.setSender(user.getUsername());
        return chatMessage;
    }

}

