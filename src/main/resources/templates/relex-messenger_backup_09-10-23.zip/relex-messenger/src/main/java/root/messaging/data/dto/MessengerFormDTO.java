package root.messaging.data.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Value;

@Data
@AllArgsConstructor
public class MessengerFormDTO {

    String token;
    String recipient;

    public MessengerFormDTO() {
        this.token = null;
        this.recipient = null;
    }

}
