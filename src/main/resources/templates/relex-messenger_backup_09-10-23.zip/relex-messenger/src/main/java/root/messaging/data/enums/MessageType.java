package root.messaging.data.enums;

public enum MessageType {
    CHAT,
    PRIVATE_CHAT,
    JOIN,
    LEAVE
}
