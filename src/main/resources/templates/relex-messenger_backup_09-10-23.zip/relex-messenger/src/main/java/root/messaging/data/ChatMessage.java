package root.messaging.data;

import lombok.*;
import root.messaging.data.enums.MessageType;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChatMessage {

    private String sender;
    private String receiver;
    private String content;
    private MessageType type;

}
